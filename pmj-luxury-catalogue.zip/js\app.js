/* Admin mode, bootstrap & global listeners */
const adminModal = document.getElementById('adminModal');
const adminBackdrop = document.getElementById('adminBackdrop');

function openAdminModal() {
  adminModal.classList.add('open');
  adminBackdrop.classList.add('open');
  document.getElementById('adminCode').focus();
}

function closeAdminModal() {
  adminModal.classList.remove('open');
  adminBackdrop.classList.remove('open');
  document.getElementById('adminCode').value = '';
  document.getElementById('adminError').textContent = '';
}

document.getElementById('openAdmin').addEventListener('click', () => {
  if (adminMode) {
    adminMode = false;
    document.getElementById('adminPill').classList.add('hidden');
    if (activeProductId) renderModal();
    return;
  }
  openAdminModal();
});

document.getElementById('adminSubmit').addEventListener('click', () => {
  const val = document.getElementById('adminCode').value.trim();
  if (val === ADMIN_ACCESS_CODE) {
    adminMode = true;
    closeAdminModal();
    document.getElementById('adminPill').classList.remove('hidden');
    if (activeProductId) renderModal();
  } else {
    document.getElementById('adminError').textContent = 'Incorrect admin code.';
  }
});

adminBackdrop?.addEventListener('click', closeAdminModal);

document.getElementById('adminCode')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('adminSubmit').click();
});

/* Close modals / drawer on Escape */
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (productModal?.classList.contains('open')) closeProductModal();
  else if (drawer?.classList.contains('open')) closeDrawer();
  else if (adminModal?.classList.contains('open')) closeAdminModal();
});

/* Header scroll state */
const header = document.getElementById('siteHeader');
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 40);
}, { passive: true });

/* Preload hero image once authenticated */
function preloadHeroImage() {
  const p = PRODUCTS.find((x) => x.id === 'SPND998476');
  if (!p || !IMAGES[p.images[0]]) return;
  const img = new Image();
  img.src = IMAGES[p.images[0]];
}

if (document.body.classList.contains('catalogue-ready')) preloadHeroImage();
window.addEventListener('pmj:intro-complete', preloadHeroImage);
