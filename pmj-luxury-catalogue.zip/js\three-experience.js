/* ============================================================
   PMJ Luxury WebGL Experience — Three.js + GSAP + GLTF
   Loading → Logo Forge → Vault Doors → Camera Fly → Floating Jewel
   ============================================================ */
const PMJExperience = (() => {
  let renderer, scene, camera, vaultLeft, vaultRight, jewelGroup, particleSystem;
  let canvas, heroCanvas, heroRenderer, heroScene, heroCamera, heroJewel;
  let rafMain = null, rafHero = null;
  let ready = false;
  let mouse = { x: 0, y: 0 };

  const isMobile = () => window.innerWidth < 900;
  const prefersReducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function letterTexture(letter) {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#0b0b0d';
    ctx.fillRect(0, 0, 256, 256);
    ctx.font = '600 180px "Cormorant Garamond", Georgia, serif';
    ctx.fillStyle = '#c7a252';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(letter, 128, 138);
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    return tex;
  }

  function buildLights(target) {
    target.add(new THREE.AmbientLight(0x2a2018, 0.45));
    const key = new THREE.DirectionalLight(0xfff0d0, 1.5);
    key.position.set(4, 6, 8);
    target.add(key);
    const gold = new THREE.PointLight(0xc7a252, 2.4, 30);
    gold.position.set(-3, 1, 5);
    target.add(gold);
    const rim = new THREE.PointLight(0x7c1f2e, 0.85, 20);
    rim.position.set(3, -1, 4);
    target.add(rim);
  }

  function buildVault() {
    const doorMat = new THREE.MeshStandardMaterial({
      color: 0x14100c,
      metalness: 0.92,
      roughness: 0.28,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      map: letterTexture('P'),
      metalness: 1,
      roughness: 0.18,
      color: 0xffffff,
    });
    const goldMatJ = goldMat.clone();
    goldMatJ.map = letterTexture('J');

    vaultLeft = new THREE.Group();
    const leftDoor = new THREE.Mesh(new THREE.BoxGeometry(2.05, 5.2, 0.14), doorMat);
    leftDoor.position.x = 1.025;
    vaultLeft.add(leftDoor);
    const pEmblem = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.1), goldMat);
    pEmblem.position.set(1.025, 0, 0.08);
    vaultLeft.add(pEmblem);
    vaultLeft.position.x = -2.05;
    scene.add(vaultLeft);

    vaultRight = new THREE.Group();
    const rightDoor = new THREE.Mesh(new THREE.BoxGeometry(2.05, 5.2, 0.14), doorMat);
    rightDoor.position.x = -1.025;
    vaultRight.add(rightDoor);
    const jEmblem = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.1), goldMatJ);
    jEmblem.position.set(-1.025, 0, 0.08);
    vaultRight.add(jEmblem);
    vaultRight.position.x = 2.05;
    scene.add(vaultRight);
  }

  function buildParticles(count) {
    const n = isMobile() ? Math.floor(count * 0.45) : count;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 0.5;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 0.5;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    particleSystem = new THREE.Points(
      geo,
      new THREE.PointsMaterial({
        color: 0xc7a252,
        size: isMobile() ? 0.04 : 0.06,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    scene.add(particleSystem);
  }

  async function setJewelFromProduct(product) {
    if (jewelGroup) {
      PMJModelLoader.disposeObject(jewelGroup);
      scene.remove(jewelGroup);
    }
    jewelGroup = await PMJModelLoader.loadDisplay(product, {
      targetSize: 2,
      withPedestal: true,
      renderer,
    });

    const glow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.6, 2.6),
      new THREE.MeshBasicMaterial({
        color: 0xc7a252,
        transparent: true,
        opacity: 0.1,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    glow.position.z = -0.08;
    jewelGroup.add(glow);

    jewelGroup.visible = false;
    jewelGroup.position.set(0, -0.15, 0);
    scene.add(jewelGroup);
  }

  function initMain() {
    canvas = document.getElementById('experienceCanvas');
    if (!canvas || typeof THREE === 'undefined') return false;

    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile() ? 1.5 : 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    if (THREE.sRGBEncoding) renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.physicallyCorrectLights = true;

    PMJModelLoader.initEnvMap(renderer);

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0b0d);
    scene.fog = new THREE.FogExp2(0x0b0b0d, 0.036);

    camera = new THREE.PerspectiveCamera(40, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 0, 8);

    buildLights(scene);
    buildVault();
    buildParticles(1400);

    window.addEventListener('resize', onResize);
    document.addEventListener('mousemove', onMouseMove, { passive: true });
    ready = true;
    return true;
  }

  function onMouseMove(e) {
    mouse.x = (e.clientX / window.innerWidth - 0.5) * 2;
    mouse.y = (e.clientY / window.innerHeight - 0.5) * 2;
  }

  function onResize() {
    if (!renderer || !camera) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    if (heroRenderer && heroCamera) {
      const box = document.getElementById('heroVisual');
      if (box) {
        const rect = box.getBoundingClientRect();
        heroRenderer.setSize(rect.width, rect.height);
        heroCamera.aspect = rect.width / rect.height;
        heroCamera.updateProjectionMatrix();
      }
    }
  }

  function burstParticles() {
    if (!particleSystem) return;
    const arr = particleSystem.geometry.attributes.position.array;
    const start = Float32Array.from(arr);
    const end = new Float32Array(arr.length);
    for (let i = 0; i < arr.length; i += 3) {
      const a = Math.random() * Math.PI * 2;
      const r = 2 + Math.random() * 5;
      end[i] = Math.cos(a) * r;
      end[i + 1] = Math.sin(a) * r * 0.55;
      end[i + 2] = (Math.random() - 0.5) * 3;
    }
    gsap.to(particleSystem.material, { opacity: 0.95, duration: 0.4 });
    const proxy = { t: 0 };
    gsap.to(proxy, {
      t: 1,
      duration: 2.4,
      ease: 'power2.out',
      onUpdate: () => {
        for (let i = 0; i < arr.length; i++) {
          arr[i] = start[i] + (end[i] - start[i]) * proxy.t;
        }
        particleSystem.geometry.attributes.position.needsUpdate = true;
      },
      onComplete: () => gsap.to(particleSystem.material, { opacity: 0, duration: 1 }),
    });
  }

  function animateMain() {
    rafMain = requestAnimationFrame(animateMain);
    if (jewelGroup?.visible) {
      jewelGroup.rotation.y += 0.0035;
      jewelGroup.position.y = -0.15 + Math.sin(Date.now() * 0.001) * 0.07;
      jewelGroup.rotation.x = mouse.y * 0.06;
      jewelGroup.rotation.z = mouse.x * 0.03;
    }
    renderer.render(scene, camera);
  }

  async function initHeroViewer(productOrKey) {
    heroCanvas = document.getElementById('heroCanvas');
    const wrap = document.getElementById('heroVisual');
    if (!heroCanvas || !wrap || typeof THREE === 'undefined') return;

    const product =
      typeof productOrKey === 'object'
        ? productOrKey
        : PRODUCTS.find((p) => p.images.includes(productOrKey)) || PRODUCTS[0];

    if (rafHero) cancelAnimationFrame(rafHero);
    if (heroJewel) PMJModelLoader.disposeObject(heroJewel);

    document.getElementById('heroImg')?.classList.add('hidden');

    const rect = wrap.getBoundingClientRect();
    heroRenderer = new THREE.WebGLRenderer({ canvas: heroCanvas, antialias: true, alpha: true });
    heroRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    heroRenderer.setSize(rect.width, rect.height);
    if (THREE.sRGBEncoding) heroRenderer.outputEncoding = THREE.sRGBEncoding;
    heroRenderer.toneMapping = THREE.ACESFilmicToneMapping;

    heroScene = new THREE.Scene();
    buildLights(heroScene);
    PMJModelLoader.initEnvMap(heroRenderer);

    heroCamera = new THREE.PerspectiveCamera(40, rect.width / rect.height, 0.1, 50);
    heroCamera.position.z = 3.4;

    heroJewel = await PMJModelLoader.loadDisplay(product, {
      targetSize: 1.6,
      withPedestal: false,
      renderer: heroRenderer,
    });
    heroScene.add(heroJewel);

    (function tick() {
      rafHero = requestAnimationFrame(tick);
      if (heroJewel) {
        heroJewel.rotation.y += 0.004;
        heroJewel.position.y = Math.sin(Date.now() * 0.0014) * 0.05;
      }
      heroRenderer.render(heroScene, heroCamera);
    })();
  }

  function runLoadingForge(onComplete) {
    const screen = document.getElementById('loadingScreen');
    const bar = document.getElementById('loadingBar');
    const logo = document.getElementById('forgeLogo');
    if (!screen || typeof gsap === 'undefined') {
      onComplete();
      return;
    }

    screen.classList.add('active');
    gsap.timeline({
      onComplete: () => {
        gsap.to(screen, {
          opacity: 0,
          duration: 0.65,
          delay: 0.15,
          onComplete: () => {
            screen.classList.remove('active');
            screen.style.display = 'none';
            onComplete();
          },
        });
      },
    })
      .fromTo(logo, { scale: 0.25, opacity: 0, filter: 'blur(10px)' }, { scale: 1, opacity: 1, filter: 'blur(0px)', duration: 1.2, ease: 'power3.out' })
      .fromTo(bar, { scaleX: 0 }, { scaleX: 1, duration: 1.5, ease: 'power2.inOut' }, 0.35)
      .to(logo, { filter: 'drop-shadow(0 0 28px rgba(199,162,82,0.75))', duration: 0.6, yoyo: true, repeat: 2 }, 0.55);
  }

  async function playSequence(onComplete) {
    if (!ready && !initMain()) {
      onComplete();
      return;
    }

    const heroProduct = PRODUCTS.find((p) => p.id === 'SPND998476') || PRODUCTS[0];
    await setJewelFromProduct(heroProduct);

    canvas.classList.add('active');
    document.body.classList.add('intro-active', 'vault-sealed');
    animateMain();

    if (prefersReducedMotion()) {
      finishSequence(onComplete, heroProduct);
      return;
    }

    vaultLeft.rotation.y = 0;
    vaultRight.rotation.y = 0;
    jewelGroup.visible = false;
    camera.position.set(0, 0.05, 8);
    camera.lookAt(0, 0, 0);

    const tl = gsap.timeline();

    tl.to('#forgeFlash', { opacity: 0.85, duration: 0.12 })
      .to('#forgeFlash', { opacity: 0, duration: 0.65 })
      .to({}, { duration: 0.5 })
      .add(() => burstParticles())
      .to(vaultLeft.rotation, { y: -Math.PI * 0.52, duration: 1.65, ease: 'power3.inOut' }, '-=0.2')
      .to(vaultRight.rotation, { y: Math.PI * 0.52, duration: 1.65, ease: 'power3.inOut' }, '<')
      .to(camera.position, { z: 2.8, y: 0.25, duration: 1.85, ease: 'power2.inOut' }, '-=0.85')
      .to(camera.position, { z: -0.8, duration: 1.35, ease: 'power1.inOut' }, '+=0.05')
      .add(() => {
        jewelGroup.visible = true;
        jewelGroup.scale.set(0.2, 0.2, 0.2);
      })
      .to(jewelGroup.scale, { x: 1, y: 1, z: 1, duration: 1.35, ease: 'back.out(1.5)' })
      .to(camera.position, { x: 0, y: 0, z: 4.5, duration: 1.55, ease: 'power2.out' }, '<')
      .to({}, { duration: 2.1 })
      .add(() => finishSequence(onComplete, heroProduct));
  }

  function finishSequence(onComplete, heroProduct) {
    gsap.to(canvas, {
      opacity: 0,
      duration: 1,
      ease: 'power2.inOut',
      onComplete: () => {
        canvas.classList.remove('active');
        if (rafMain) cancelAnimationFrame(rafMain);
        onComplete();
        if (heroProduct) initHeroViewer(heroProduct);
      },
    });
  }

  function bootstrap(onReady) {
    if (typeof THREE === 'undefined') {
      onReady();
      return;
    }
    initMain();
    runLoadingForge(onReady);
  }

  return { bootstrap, playSequence, initHeroViewer, ready: () => ready };
})();

window.PMJExperience = PMJExperience;
