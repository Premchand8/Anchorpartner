/* 360° interactive product viewer — GLTF + OrbitControls + photo fallback */
const Viewer360 = (() => {
  let renderer, scene, camera, controls, meshGroup, canvas, rafId, rendererRef;
  let images = [];
  let angleIndex = 0;
  let useBillboardSwap = false;

  function dispose() {
    if (rafId) cancelAnimationFrame(rafId);
    if (meshGroup) PMJModelLoader.disposeObject(meshGroup);
    meshGroup = null;
    if (renderer) renderer.dispose();
    renderer = null;
    controls = null;
    scene = null;
    useBillboardSwap = false;
  }

  function buildLights(target) {
    target.add(new THREE.AmbientLight(0x2a2018, 0.5));
    const key = new THREE.DirectionalLight(0xfff5e0, 1.4);
    key.position.set(2, 4, 5);
    target.add(key);
    const gold = new THREE.PointLight(0xc7a252, 1.4, 14);
    gold.position.set(-2, 0, 3);
    target.add(gold);
  }

  function loadTexture(url) {
    return new Promise((resolve) => {
      new THREE.TextureLoader().load(
        url,
        (t) => {
          t.anisotropy = 8;
          if (THREE.sRGBEncoding) t.encoding = THREE.sRGBEncoding;
          resolve(t);
        },
        undefined,
        () => resolve(null)
      );
    });
  }

  function findBillboardPlane(group) {
    let plane = null;
    group.traverse((c) => {
      if (c.isMesh && c.material?.map && !plane) plane = c;
    });
    return plane;
  }

  async function show(product, startIndex = 0) {
    canvas = document.getElementById('viewer360Canvas');
    const wrap = document.getElementById('viewer360Wrap');
    const hint = wrap?.querySelector('.viewer360-hint');
    if (!canvas || !wrap || !product || typeof THREE === 'undefined') return false;

    dispose();
    images = product.images.map((k) => IMAGES[k]).filter(Boolean);
    angleIndex = Math.min(startIndex, Math.max(images.length - 1, 0));

    const rect = wrap.getBoundingClientRect();
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(rect.width, rect.height);
    if (THREE.sRGBEncoding) renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    rendererRef = renderer;

    PMJModelLoader.initEnvMap(renderer);

    camera = new THREE.PerspectiveCamera(38, rect.width / rect.height, 0.1, 50);
    camera.position.set(0, 0, 4.2);

    scene = new THREE.Scene();
    buildLights(scene);

    meshGroup = await PMJModelLoader.loadDisplay(product, {
      imageKey: product.images[angleIndex],
      targetSize: 2.2,
      withPedestal: false,
      renderer,
    });

    useBillboardSwap = meshGroup.userData.source === 'billboard' && images.length > 1;
    scene.add(meshGroup);

    if (typeof THREE.OrbitControls !== 'undefined') {
      controls = new THREE.OrbitControls(camera, canvas);
      controls.enableDamping = true;
      controls.dampingFactor = 0.055;
      controls.enablePan = false;
      controls.minDistance = 2.2;
      controls.maxDistance = 6.5;
      controls.minPolarAngle = Math.PI / 5;
      controls.maxPolarAngle = Math.PI / 1.35;
    }

    if (hint) {
      hint.textContent = meshGroup.userData.source === 'gltf'
        ? 'Drag to rotate · Scroll to zoom · Real 3D model'
        : 'Drag to rotate · Scroll to zoom';
    }

    canvas.style.display = 'block';
    document.getElementById('pmMainImg')?.classList.add('hidden');

    let lastAngle = 0;
    function tick() {
      rafId = requestAnimationFrame(tick);
      if (controls) controls.update();
      if (meshGroup) {
        if (!controls && meshGroup.userData.source === 'procedural') {
          meshGroup.rotation.y += 0.004;
        }
        meshGroup.position.y = Math.sin(Date.now() * 0.0012) * 0.035;
      }

      if (useBillboardSwap && meshGroup) {
        const a = ((meshGroup.rotation.y % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        const seg = (Math.PI * 2) / images.length;
        const idx = Math.floor(a / seg) % images.length;
        if (idx !== angleIndex && Math.abs(a - lastAngle) > 0.04) {
          angleIndex = idx;
          loadTexture(images[idx]).then((t) => {
            const plane = findBillboardPlane(meshGroup);
            if (t && plane?.material) {
              plane.material.map = t;
              plane.material.needsUpdate = true;
            }
          });
        }
        lastAngle = a;
      }

      renderer.render(scene, camera);
    }
    tick();
    return true;
  }

  function hide() {
    dispose();
    if (canvas) canvas.style.display = 'none';
    document.getElementById('pmMainImg')?.classList.remove('hidden');
  }

  function resize() {
    if (!renderer || !camera) return;
    const wrap = document.getElementById('viewer360Wrap');
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    renderer.setSize(rect.width, rect.height);
    camera.aspect = rect.width / rect.height;
    camera.updateProjectionMatrix();
  }

  window.addEventListener('resize', resize);
  return { show, hide, resize };
})();

window.Viewer360 = Viewer360;
