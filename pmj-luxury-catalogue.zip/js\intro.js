/* Login gate & cinematic WebGL intro sequence */
const PARTNER_ACCESS_CODE = 'PMJVIP2026';
const ADMIN_ACCESS_CODE = 'PMJADMIN26';

const loginGate = document.getElementById('loginGate');
const introBox = document.getElementById('introBox');
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const INTRO_MS = 2800;

function revealCatalogue() {
  document.body.classList.remove('intro-active', 'vault-sealed');
  document.body.classList.add('catalogue-ready');
  if (introBox) {
    introBox.classList.remove('opening', 'is-visible');
    introBox.classList.add('done');
  }
  window.dispatchEvent(new CustomEvent('pmj:intro-complete'));
}

/* CSS vault fallback when WebGL unavailable */
function playCssIntroFallback() {
  if (!introBox) {
    revealCatalogue();
    return;
  }
  document.body.classList.add('vault-sealed', 'intro-active');
  introBox.classList.add('is-visible');
  void introBox.offsetWidth;
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      introBox.classList.add('opening');
      if (typeof spawnIntroParticles === 'function') spawnIntroParticles(36);
    });
  });
  setTimeout(revealCatalogue, INTRO_MS);
}

function playIntro() {
  const useWebGL =
    !prefersReducedMotion &&
    window.PMJExperience &&
    typeof THREE !== 'undefined' &&
    typeof gsap !== 'undefined';

  if (useWebGL) {
    PMJExperience.playSequence(revealCatalogue);
  } else {
    playCssIntroFallback();
  }
}

function attemptLogin() {
  const val = document.getElementById('accessCode').value.trim();
  const errEl = document.getElementById('loginError');

  if (val !== PARTNER_ACCESS_CODE) {
    errEl.textContent = 'Incorrect access code. Please try again.';
    document.getElementById('accessCode').focus();
    return;
  }

  sessionStorage.setItem('pmj_partner_authed', 'true');
  errEl.textContent = '';
  loginGate.classList.add('fade-out');

  setTimeout(() => {
    loginGate.style.display = 'none';
    playIntro();
  }, 480);
}

document.getElementById('loginBtn').addEventListener('click', attemptLogin);
document.getElementById('accessCode').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') attemptLogin();
});

function onAppReady() {
  const authed = sessionStorage.getItem('pmj_partner_authed') === 'true';
  loginGate.style.visibility = '';

  if (authed) {
    loginGate.style.display = 'none';
    if (introBox) introBox.classList.add('done');
    document.body.classList.add('catalogue-ready');
    const hero = PRODUCTS.find((p) => p.id === 'SPND998476');
    if (hero && window.PMJExperience) {
      PMJExperience.initHeroViewer(hero);
    }
  } else {
    document.body.classList.add('vault-sealed');
  }
}

/* Bootstrap: loading forge → login gate */
function startBootstrap() {
  loginGate.style.visibility = 'hidden';

  if (window.PMJExperience && typeof THREE !== 'undefined') {
    PMJExperience.bootstrap(onAppReady);
  } else {
    onAppReady();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startBootstrap);
} else {
  startBootstrap();
}
