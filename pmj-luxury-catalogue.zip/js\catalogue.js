/* Catalogue rendering, filters & search */
let wishlist = [];
let currentFilter = 'all';
let searchQuery = '';
let activeProductId = null;
let adminMode = false;

function loadOverrides(){
  try { return JSON.parse(localStorage.getItem('pmj_admin_overrides') || '{}'); } catch(e){ return {}; }
}
function saveOverrides(obj){
  localStorage.setItem('pmj_admin_overrides', JSON.stringify(obj));
}
function getProductData(id){
  const base = PRODUCTS.find(p=>p.id===id);
  const overrides = loadOverrides()[id] || {};
  return {
    ...base,
    name: overrides.name || base.name,
    description: overrides.description || base.description,
    purity: overrides.purity || SPEC_DEFAULTS.purity,
    gross: overrides.gross || SPEC_DEFAULTS.gross,
    netGold: overrides.netGold || SPEC_DEFAULTS.netGold,
    diamond: overrides.diamond || SPEC_DEFAULTS.diamond,
    stones: overrides.stones || SPEC_DEFAULTS.stones,
    price: overrides.price || SPEC_DEFAULTS.price,
  };
}

function setHero(){
  const p = getProductData('SPND998476');
  const img = document.getElementById('heroImg');
  if (img) img.src = IMAGES[p.images[0]] || '';
  document.getElementById('heroCaption').textContent = p.name;
}

const grid = document.getElementById('productGrid');
const wishlistCountEl = document.getElementById('wishlistCount');
const wishlistTab = document.getElementById('openDrawer');

setHero();

function getFilteredProducts(){
  let items = currentFilter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.cat === currentFilter);
  if (!searchQuery) return items;
  const q = searchQuery.toLowerCase();
  return items.filter((base) => {
    const p = getProductData(base.id);
    return (
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.id.toLowerCase().includes(q) ||
      p.catLabel.toLowerCase().includes(q)
    );
  });
}

function staggerCards(){
  document.querySelectorAll('.card').forEach((card, i) => {
    card.classList.add('card-enter');
    card.style.animationDelay = `${Math.min(i * 0.06, 0.6)}s`;
  });
}

function renderGrid(){
  const items = getFilteredProducts();
  grid.innerHTML = items.map(base=>{
    const p = getProductData(base.id);
    const multi = p.images.length > 1;
    return `
    <div class="card" data-id="${p.id}">
      <div class="card-media" data-id="${p.id}">
        ${multi ? `<span class="gallery-badge">◈ ${p.images.length} views</span>` : ''}
        <button class="heart-btn ${wishlist.includes(p.id)?'active':''}" data-id="${p.id}" aria-label="Add to wishlist">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-10-9.3C.4 8.1 2 4.5 5.6 4c2-.3 3.8.7 4.9 2.4C11.6 4.7 13.4 3.7 15.4 4c3.6.5 5.2 4.1 3.6 7.7C19.5 16.3 12 21 12 21z"/></svg>
        </button>
        <img src="${IMAGES[p.images[0]]}" alt="${p.name}" loading="lazy">
      </div>
      <div class="card-body">
        <div class="card-cat">${p.catLabel}</div>
        <h3 class="card-name">${p.name}</h3>
        <div class="card-desc">${p.description}</div>
        <div class="card-actions">
          <span class="add-link" data-id="${p.id}">${wishlist.includes(p.id) ? '✓ Added to wishlist' : '+ Add to wishlist'}</span>
          <span class="view-link" data-id="${p.id}">View details</span>
        </div>
      </div>
    </div>`;
  }).join('');
  attachTilt();
  if (document.body.classList.contains('catalogue-ready')) staggerCards();
}
renderGrid();

document.getElementById('searchInput')?.addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  renderGrid();
});

document.querySelectorAll('.filter-chip').forEach(chip=>{
  chip.addEventListener('click', ()=>{
    document.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
    chip.classList.add('active');
    currentFilter = chip.dataset.filter;
    renderGrid();
  });
});

/* 3D tilt on hover */
function attachTilt(){
  document.querySelectorAll('.card').forEach(card=>{
    card.addEventListener('mousemove', e=>{
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `rotateY(${x*6}deg) rotateX(${-y*6}deg) translateZ(0)`;
    });
    card.addEventListener('mouseleave', ()=>{ card.style.transform = 'rotateY(0) rotateX(0)'; });
  });
}

grid.addEventListener('click', (e)=>{
  const heart = e.target.closest('.heart-btn');
  const view = e.target.closest('.view-link');
  const media = e.target.closest('.card-media');
  const addLink = e.target.closest('.add-link');
  if(heart){ toggleWishlist(heart.dataset.id, heart); return; }
  if(addLink){ toggleWishlist(addLink.dataset.id, addLink); return; }
  if(view || media){ openProductModal((view||media).dataset.id); return; }
});

function toggleWishlist(id, sourceEl){
  const idx = wishlist.indexOf(id);
  if(idx > -1){ wishlist.splice(idx,1); }
  else { wishlist.push(id); if(sourceEl) flyThread(sourceEl); }
  renderGrid();
  updateCount();
  renderDrawer();
  if(activeProductId === id) refreshModalHeart();
}

function updateCount(){
  wishlistCountEl.textContent = wishlist.length;
  wishlistTab.classList.remove('pulse');
  requestAnimationFrame(()=> wishlistTab.classList.add('pulse'));
}

function flyThread(sourceEl){
  const start = sourceEl.getBoundingClientRect();
  const end = document.getElementById('openDrawer').getBoundingClientRect();
  const dot = document.createElement('div');
  dot.className = 'thread-dot';
  dot.style.left = (start.left + start.width/2) + 'px';
  dot.style.top = (start.top + start.height/2) + 'px';
  document.body.appendChild(dot);
  const dx = (end.left + end.width/2) - (start.left + start.width/2);
  const dy = (end.top + end.height/2) - (start.top + start.height/2);
  dot.animate([
    { transform:'translate(0,0) scale(1)', opacity:1 },
    { transform:`translate(${dx*0.5}px, ${dy*0.5 - 60}px) scale(1.3)`, opacity:1, offset:0.6 },
    { transform:`translate(${dx}px, ${dy}px) scale(.3)`, opacity:0 }
  ], { duration:650, easing:'cubic-bezier(.22,.61,.36,1)' }).onfinish = ()=> dot.remove();
}

window.addEventListener('pmj:intro-complete', staggerCards);
if (document.body.classList.contains('catalogue-ready')) {
  requestAnimationFrame(staggerCards);
}