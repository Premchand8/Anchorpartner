/* Product detail modal & 360° WebGL viewer */
const pmOverlay = document.getElementById('pmOverlay');
const productModal = document.getElementById('productModal');
let pmImageIndex = 0;

function openProductModal(id) {
  activeProductId = id;
  pmImageIndex = 0;
  renderModal();
  pmOverlay.classList.add('open');
  productModal.classList.add('open');
}

function closeProductModal() {
  pmOverlay.classList.remove('open');
  productModal.classList.remove('open');
  document.getElementById('pmEditFields').classList.remove('show');
  if (window.Viewer360) Viewer360.hide();
  activeProductId = null;
}

document.getElementById('pmClose').addEventListener('click', closeProductModal);
pmOverlay.addEventListener('click', closeProductModal);

function renderModal() {
  const p = getProductData(activeProductId);
  document.getElementById('pmCat').textContent = p.catLabel + ' · ' + p.id;
  document.getElementById('pmName').textContent = p.name;
  document.getElementById('pmDesc').textContent = p.description;

  const mainImg = document.getElementById('pmMainImg');
  mainImg.src = IMAGES[p.images[pmImageIndex]];
  mainImg.alt = p.name;

  document.getElementById('pmThumbs').innerHTML = p.images.map((key, i) => `
    <div class="pm-thumb ${i === pmImageIndex ? 'active' : ''}" data-i="${i}">
      <img src="${IMAGES[key]}" alt="View ${i + 1}">
    </div>
  `).join('');

  document.getElementById('pmSpecs').innerHTML = `
    <div class="spec-row"><span class="k">Purity</span><span class="v">${p.purity}</span></div>
    <div class="spec-row"><span class="k">Gross Weight</span><span class="v">${p.gross}</span></div>
    <div class="spec-row"><span class="k">Net Gold Weight</span><span class="v">${p.netGold}</span></div>
    <div class="spec-row"><span class="k">Diamond / Stone Weight</span><span class="v">${p.diamond}</span></div>
    <div class="spec-row"><span class="k">Stone Details</span><span class="v">${p.stones}</span></div>
    <div class="spec-row"><span class="k">Price</span><span class="v">${p.price}</span></div>
  `;

  refreshModalHeart();
  document.getElementById('editName').value = p.name;
  document.getElementById('editDesc').value = p.description;
  document.getElementById('editPurity').value = p.purity === SPEC_DEFAULTS.purity ? '' : p.purity;
  document.getElementById('editGross').value = p.gross === SPEC_DEFAULTS.gross ? '' : p.gross;
  document.getElementById('editNetGold').value = p.netGold === SPEC_DEFAULTS.netGold ? '' : p.netGold;
  document.getElementById('editDiamond').value = p.diamond === SPEC_DEFAULTS.diamond ? '' : p.diamond;
  document.getElementById('editStones').value = p.stones === SPEC_DEFAULTS.stones ? '' : p.stones;
  document.getElementById('editPrice').value = p.price === SPEC_DEFAULTS.price ? '' : p.price;
  document.getElementById('pmEditToggle').style.display = adminMode ? 'inline-block' : 'none';

  /* 360° viewer — GLTF model or photo orbit fallback */
  if (window.Viewer360 && typeof THREE !== 'undefined' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    Viewer360.show(p, pmImageIndex);
  } else {
    if (window.Viewer360) Viewer360.hide();
    mainImg.classList.remove('hidden');
  }
}

function refreshModalHeart() {
  const active = wishlist.includes(activeProductId);
  const btn = document.getElementById('pmHeart');
  btn.classList.toggle('active', active);
  document.getElementById('pmHeartLabel').textContent = active ? 'Added to Wishlist' : 'Add to Wishlist';
}

document.getElementById('pmHeart').addEventListener('click', () =>
  toggleWishlist(activeProductId, document.getElementById('pmHeart'))
);

document.getElementById('pmThumbs').addEventListener('click', (e) => {
  const t = e.target.closest('.pm-thumb');
  if (!t) return;
  pmImageIndex = parseInt(t.dataset.i, 10);
  renderModal();
});

document.getElementById('pmEditToggle').addEventListener('click', () => {
  document.getElementById('pmEditFields').classList.toggle('show');
});

document.getElementById('pmEditSave').addEventListener('click', () => {
  const overrides = loadOverrides();
  overrides[activeProductId] = {
    name: document.getElementById('editName').value.trim(),
    description: document.getElementById('editDesc').value.trim(),
    purity: document.getElementById('editPurity').value.trim(),
    gross: document.getElementById('editGross').value.trim(),
    netGold: document.getElementById('editNetGold').value.trim(),
    diamond: document.getElementById('editDiamond').value.trim(),
    stones: document.getElementById('editStones').value.trim(),
    price: document.getElementById('editPrice').value.trim(),
  };
  saveOverrides(overrides);
  renderModal();
  renderGrid();
  document.getElementById('pmEditFields').classList.remove('show');
});
